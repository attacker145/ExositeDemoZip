![logo](http://exosite-labs.github.io/images/logo_linear.png)

The latest documentation for the Exosite C Libraries can be found
on the Exosite [website](http://c-lib-testbed-ynimj8q4.exosite.biz/index.html)
